﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Card_Identifier
{
    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();
        }

        private void eightOfDiamonds_Click(object sender, EventArgs e)
        {
            cardNameLabel.Text = "Eight of Daimonds";
        }

        private void kingOfSpades_Click(object sender, EventArgs e)
        {
            cardNameLabel.Text = "King of Spades";
        }

        private void threeOfClubs_Click(object sender, EventArgs e)
        {
            cardNameLabel.Text = "Three of Clubs";
        }

        private void aceOfSpades_Click(object sender, EventArgs e)
        {
            cardNameLabel.Text = " Ace of Spades";
        }

        private void pictureBox1_Click(object sender, EventArgs e)
        {
            cardNameLabel.Text = "Joker";
        }
    }
}
