﻿namespace Card_Identifier
{
    partial class Form1
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(Form1));
            this.instructionLabel = new System.Windows.Forms.Label();
            this.cardNameLabel = new System.Windows.Forms.Label();
            this.eightOfDaimonds = new System.Windows.Forms.PictureBox();
            this.kingOfSpades = new System.Windows.Forms.PictureBox();
            this.threeOfClubs = new System.Windows.Forms.PictureBox();
            this.aceOfSpades = new System.Windows.Forms.PictureBox();
            this.joker = new System.Windows.Forms.PictureBox();
            ((System.ComponentModel.ISupportInitialize)(this.eightOfDaimonds)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.kingOfSpades)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.threeOfClubs)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.aceOfSpades)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.joker)).BeginInit();
            this.SuspendLayout();
            // 
            // instructionLabel
            // 
            this.instructionLabel.AutoSize = true;
            this.instructionLabel.Font = new System.Drawing.Font("Microsoft Sans Serif", 25F);
            this.instructionLabel.Location = new System.Drawing.Point(240, 23);
            this.instructionLabel.Name = "instructionLabel";
            this.instructionLabel.Size = new System.Drawing.Size(493, 39);
            this.instructionLabel.TabIndex = 0;
            this.instructionLabel.Text = "Click a card to find out what it is";
            // 
            // cardNameLabel
            // 
            this.cardNameLabel.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.cardNameLabel.Font = new System.Drawing.Font("Microsoft Sans Serif", 25F);
            this.cardNameLabel.Location = new System.Drawing.Point(109, 463);
            this.cardNameLabel.Name = "cardNameLabel";
            this.cardNameLabel.Size = new System.Drawing.Size(754, 66);
            this.cardNameLabel.TabIndex = 1;
            this.cardNameLabel.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // eightOfDaimonds
            // 
            this.eightOfDaimonds.Image = ((System.Drawing.Image)(resources.GetObject("eightOfDaimonds.Image")));
            this.eightOfDaimonds.Location = new System.Drawing.Point(12, 86);
            this.eightOfDaimonds.Name = "eightOfDaimonds";
            this.eightOfDaimonds.Size = new System.Drawing.Size(183, 254);
            this.eightOfDaimonds.TabIndex = 2;
            this.eightOfDaimonds.TabStop = false;
            this.eightOfDaimonds.Click += new System.EventHandler(this.eightOfDiamonds_Click);
            // 
            // kingOfSpades
            // 
            this.kingOfSpades.Image = ((System.Drawing.Image)(resources.GetObject("kingOfSpades.Image")));
            this.kingOfSpades.Location = new System.Drawing.Point(201, 86);
            this.kingOfSpades.Name = "kingOfSpades";
            this.kingOfSpades.Size = new System.Drawing.Size(181, 254);
            this.kingOfSpades.TabIndex = 3;
            this.kingOfSpades.TabStop = false;
            this.kingOfSpades.Click += new System.EventHandler(this.kingOfSpades_Click);
            // 
            // threeOfClubs
            // 
            this.threeOfClubs.Image = ((System.Drawing.Image)(resources.GetObject("threeOfClubs.Image")));
            this.threeOfClubs.Location = new System.Drawing.Point(388, 86);
            this.threeOfClubs.Name = "threeOfClubs";
            this.threeOfClubs.Size = new System.Drawing.Size(181, 254);
            this.threeOfClubs.TabIndex = 4;
            this.threeOfClubs.TabStop = false;
            this.threeOfClubs.Click += new System.EventHandler(this.threeOfClubs_Click);
            // 
            // aceOfSpades
            // 
            this.aceOfSpades.Image = ((System.Drawing.Image)(resources.GetObject("aceOfSpades.Image")));
            this.aceOfSpades.Location = new System.Drawing.Point(575, 86);
            this.aceOfSpades.Name = "aceOfSpades";
            this.aceOfSpades.Size = new System.Drawing.Size(179, 254);
            this.aceOfSpades.TabIndex = 5;
            this.aceOfSpades.TabStop = false;
            this.aceOfSpades.Click += new System.EventHandler(this.aceOfSpades_Click);
            // 
            // joker
            // 
            this.joker.Image = ((System.Drawing.Image)(resources.GetObject("joker.Image")));
            this.joker.Location = new System.Drawing.Point(760, 86);
            this.joker.Name = "joker";
            this.joker.Size = new System.Drawing.Size(176, 254);
            this.joker.TabIndex = 6;
            this.joker.TabStop = false;
            this.joker.Click += new System.EventHandler(this.pictureBox1_Click);
            // 
            // Form1
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(940, 563);
            this.Controls.Add(this.joker);
            this.Controls.Add(this.aceOfSpades);
            this.Controls.Add(this.threeOfClubs);
            this.Controls.Add(this.kingOfSpades);
            this.Controls.Add(this.eightOfDaimonds);
            this.Controls.Add(this.cardNameLabel);
            this.Controls.Add(this.instructionLabel);
            this.Name = "Form1";
            this.Text = "Card Identifier";
            ((System.ComponentModel.ISupportInitialize)(this.eightOfDaimonds)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.kingOfSpades)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.threeOfClubs)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.aceOfSpades)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.joker)).EndInit();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.Label instructionLabel;
        private System.Windows.Forms.Label cardNameLabel;
        private System.Windows.Forms.PictureBox eightOfDaimonds;
        private System.Windows.Forms.PictureBox kingOfSpades;
        private System.Windows.Forms.PictureBox threeOfClubs;
        private System.Windows.Forms.PictureBox aceOfSpades;
        private System.Windows.Forms.PictureBox joker;
    }
}

