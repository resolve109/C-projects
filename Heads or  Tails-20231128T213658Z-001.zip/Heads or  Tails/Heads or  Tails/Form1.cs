﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Heads_or__Tails
{
    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();
        }

        private void headPictureBox_Click(object sender, EventArgs e)
        {
            
        }

        private void headsButton_Click(object sender, EventArgs e)
        {
            headPictureBox.Visible = true;
            tailsPictureBox.Visible = false;
        }

        private void tailsButton_Click(object sender, EventArgs e)
        {
            headPictureBox.Visible = false;
            tailsPictureBox.Visible = true;


        }
    }
}
