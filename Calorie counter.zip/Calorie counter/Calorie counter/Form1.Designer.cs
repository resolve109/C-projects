﻿namespace Calorie_counter
{
    partial class Form1
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(Form1));
            this.bananaPictureBox = new System.Windows.Forms.PictureBox();
            this.orangePictureBox = new System.Windows.Forms.PictureBox();
            this.cherryPictureBox = new System.Windows.Forms.PictureBox();
            this.pearPictureBox = new System.Windows.Forms.PictureBox();
            this.resetButton = new System.Windows.Forms.Button();
            this.exitButton = new System.Windows.Forms.Button();
            this.instructionsLabel = new System.Windows.Forms.Label();
            this.totalLabel = new System.Windows.Forms.Label();
            ((System.ComponentModel.ISupportInitialize)(this.bananaPictureBox)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.orangePictureBox)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.cherryPictureBox)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.pearPictureBox)).BeginInit();
            this.SuspendLayout();
            // 
            // bananaPictureBox
            // 
            this.bananaPictureBox.Image = ((System.Drawing.Image)(resources.GetObject("bananaPictureBox.Image")));
            this.bananaPictureBox.Location = new System.Drawing.Point(12, 12);
            this.bananaPictureBox.Name = "bananaPictureBox";
            this.bananaPictureBox.Size = new System.Drawing.Size(129, 156);
            this.bananaPictureBox.TabIndex = 0;
            this.bananaPictureBox.TabStop = false;
            this.bananaPictureBox.Click += new System.EventHandler(this.bananaPictureBox_Click);
            // 
            // orangePictureBox
            // 
            this.orangePictureBox.Image = ((System.Drawing.Image)(resources.GetObject("orangePictureBox.Image")));
            this.orangePictureBox.Location = new System.Drawing.Point(11, 174);
            this.orangePictureBox.Name = "orangePictureBox";
            this.orangePictureBox.Size = new System.Drawing.Size(130, 153);
            this.orangePictureBox.TabIndex = 1;
            this.orangePictureBox.TabStop = false;
            this.orangePictureBox.Click += new System.EventHandler(this.orangePictureBox_Click);
            // 
            // cherryPictureBox
            // 
            this.cherryPictureBox.Image = ((System.Drawing.Image)(resources.GetObject("cherryPictureBox.Image")));
            this.cherryPictureBox.Location = new System.Drawing.Point(147, 11);
            this.cherryPictureBox.Name = "cherryPictureBox";
            this.cherryPictureBox.Size = new System.Drawing.Size(124, 157);
            this.cherryPictureBox.TabIndex = 2;
            this.cherryPictureBox.TabStop = false;
            this.cherryPictureBox.Click += new System.EventHandler(this.cherryPictureBox_Click);
            // 
            // pearPictureBox
            // 
            this.pearPictureBox.Image = ((System.Drawing.Image)(resources.GetObject("pearPictureBox.Image")));
            this.pearPictureBox.Location = new System.Drawing.Point(147, 174);
            this.pearPictureBox.Name = "pearPictureBox";
            this.pearPictureBox.Size = new System.Drawing.Size(124, 157);
            this.pearPictureBox.TabIndex = 3;
            this.pearPictureBox.TabStop = false;
            this.pearPictureBox.Click += new System.EventHandler(this.pearPictureBox_Click);
            // 
            // resetButton
            // 
            this.resetButton.Location = new System.Drawing.Point(304, 196);
            this.resetButton.Name = "resetButton";
            this.resetButton.Size = new System.Drawing.Size(75, 23);
            this.resetButton.TabIndex = 4;
            this.resetButton.Text = "Reset";
            this.resetButton.UseVisualStyleBackColor = true;
            this.resetButton.Click += new System.EventHandler(this.resetButton_Click);
            // 
            // exitButton
            // 
            this.exitButton.Location = new System.Drawing.Point(304, 254);
            this.exitButton.Name = "exitButton";
            this.exitButton.Size = new System.Drawing.Size(75, 21);
            this.exitButton.TabIndex = 5;
            this.exitButton.Text = "Exit";
            this.exitButton.UseVisualStyleBackColor = true;
            this.exitButton.Click += new System.EventHandler(this.exitButton_Click);
            // 
            // instructionsLabel
            // 
            this.instructionsLabel.AutoSize = true;
            this.instructionsLabel.Location = new System.Drawing.Point(308, 73);
            this.instructionsLabel.Name = "instructionsLabel";
            this.instructionsLabel.Size = new System.Drawing.Size(71, 13);
            this.instructionsLabel.TabIndex = 6;
            this.instructionsLabel.Text = "Total Calories";
            // 
            // totalLabel
            // 
            this.totalLabel.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.totalLabel.Location = new System.Drawing.Point(293, 123);
            this.totalLabel.Name = "totalLabel";
            this.totalLabel.Size = new System.Drawing.Size(100, 23);
            this.totalLabel.TabIndex = 7;
            this.totalLabel.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // Form1
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(410, 330);
            this.Controls.Add(this.totalLabel);
            this.Controls.Add(this.instructionsLabel);
            this.Controls.Add(this.exitButton);
            this.Controls.Add(this.resetButton);
            this.Controls.Add(this.pearPictureBox);
            this.Controls.Add(this.cherryPictureBox);
            this.Controls.Add(this.orangePictureBox);
            this.Controls.Add(this.bananaPictureBox);
            this.Name = "Form1";
            this.Text = "Calorie Counter";
            ((System.ComponentModel.ISupportInitialize)(this.bananaPictureBox)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.orangePictureBox)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.cherryPictureBox)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.pearPictureBox)).EndInit();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.PictureBox bananaPictureBox;
        private System.Windows.Forms.PictureBox orangePictureBox;
        private System.Windows.Forms.PictureBox cherryPictureBox;
        private System.Windows.Forms.PictureBox pearPictureBox;
        private System.Windows.Forms.Button resetButton;
        private System.Windows.Forms.Button exitButton;
        private System.Windows.Forms.Label instructionsLabel;
        private System.Windows.Forms.Label totalLabel;
    }
}

